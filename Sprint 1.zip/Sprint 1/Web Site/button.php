<html>

<form>
<a href ="Ceng316.php"><input type="button" value="Log in" /></a>
</html>