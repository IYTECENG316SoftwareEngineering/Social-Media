
<html>
<head>
<title>
Log in
</title>
</head>	
<body>
	 	<table align="center" border="0">
	 	<tr>
		<form action="login.php" method="POST">

			<td><b>Username:</b></td><td> <input type="text" name="username"></td>
			</tr>
			<tr>
			<td><b>Password:</b></td><td> <input type="password" name="password"></td>
			</tr>
			<tr>
			<td></td><td><button style="float:right;background-color:pink" >Log in</button></td>
			</tr>
		
		</form>
</table>
</body>
</html>
