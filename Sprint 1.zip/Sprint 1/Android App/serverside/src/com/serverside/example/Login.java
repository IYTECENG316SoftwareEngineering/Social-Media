Rpackage com.serverside.example;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.CompositeFilterOperator;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;


@SuppressWarnings("serial")
public class Login extends HttpServlet{
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = req.getParameter("username");
		String userpassword = req.getParameter("userpassword");
		
		resp.getWriter().println(check(username,userpassword));
	}

	private String check(String username, String userpassword) {
		// TODO Auto-generated method stub
		//set the datastore mechanism for search the coming person
		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
		
		Filter filterUsername = new FilterPredicate("username",FilterOperator.EQUAL,username);
		
		Filter filterPassword = new FilterPredicate("userpassword",FilterOperator.EQUAL,userpassword);
		
		//combine filterUsername and filterPassword
		Filter filterUsernameAndPassword = CompositeFilterOperator.and(filterUsername,filterPassword);
		
		//We should specify that entity we are looking for , we are looking for Person entity.
		Query q = new Query("User").setFilter(filterUsernameAndPassword);
		
		//exe the query
		PreparedQuery pq = datastore.prepare(q);
		
		//return the corresponding result to Customer !
		return pq.asIterator().hasNext() ? "Login OK !" : "Login Fail !";
	}
}
