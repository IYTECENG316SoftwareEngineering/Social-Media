package com.serverside.example;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;

@SuppressWarnings("serial")
public class Register extends HttpServlet{

	//in that method getting  handled incoming request
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = req.getParameter("username");
		String userpassword = req.getParameter("userpassword");
		if(usernameValid(username)){
			resp.getWriter().println(add(username,userpassword));
		}else{
			resp.getWriter().println("Username already exist,"
					+ "try to take another");
		}
				
				
		
		
	}

	private boolean usernameValid(String username) {
		// TODO Auto-generated method stub
		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
		Filter filterUsername = new FilterPredicate("username",FilterOperator.EQUAL,username);
		
		Query q = new Query("User");
		q.setFilter(filterUsername);
		PreparedQuery pq = datastore.prepare(q);
		return pq.asIterator().hasNext() ? false : true;
		
	}

	private String add(String username, String userpassword) {
		// TODO Auto-generated method stub
		//set the datastore mechanism for writing the new person from coming informations
		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
		
		//create an entity to store onto datastore as user or person
		Entity user = new Entity("User");
		user.setProperty("username", username);
		user.setProperty("userpassword",userpassword);
		
		//user was put into Database.
		datastore.put(user);
		return "Register,OK!";
	}
}	