<?php

$username = $_POST["username"];
$password = $_POST["password"];

if($username&&$password){
	
	$connect = mysql_connect("localhost","root","") or die ("Couldn't connect !");
	mysql_select_db("phplogin") or die ("couldn't find db !");
   
    $query = mysql_query("SELECT * FROM users WHERE username=' $username' ");
    $numrows=mysql_num_rows($query);
    if($numrows != 0){


    	while( $row=mysql_fetch_assoc($query)){

    		$dbusername = $row ["username"];
    		$dbpassword = $row ["password"];

    	}

    	// check to see if they match !

    	if($username ==$dbusername&&$password==$dbpassword)
    	{
   			echo "You are in !";
    	}
    	else 
    		echo "Incorrect password !";

    }
    else 
    	die("That user doesn't exist!");
    


}
else 
die("please enter a user name and a password !");
?>